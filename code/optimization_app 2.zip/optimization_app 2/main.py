from tkinter import Tk
from view.gui import OptimizationApp

if __name__ == "__main__":
    root = Tk()
    app = OptimizationApp(root)
    root.mainloop()